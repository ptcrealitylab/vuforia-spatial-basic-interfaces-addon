# SpatialToolbox
Arduino Library to be used with the Vuforia Spatial Toobox Arduino Interface. This interdace is included in the Vuforia-Spatial-Experimental-Addon

Download this repo as a zip and add it to your Arudino Library via `Sketch > Inlude Library > Add .zip Library...`

Restart the Arduino Application.